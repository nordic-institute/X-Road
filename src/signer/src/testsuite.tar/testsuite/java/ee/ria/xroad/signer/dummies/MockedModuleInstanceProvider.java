package ee.ria.xroad.signer.dummies;

import iaik.pkcs.pkcs11.Module;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ee.ria.xroad.signer.dummies.pkcs11.ModuleMock;
import ee.ria.xroad.signer.tokenmanager.module.ModuleInstanceProvider;

public class MockedModuleInstanceProvider implements ModuleInstanceProvider {

    private static final Logger LOG =
            LoggerFactory.getLogger(MockedModuleInstanceProvider.class);

    @Override
    public Module getInstance(String path) throws Exception {
        LOG.debug("getModuleInstance({})", path);
        return ModuleMock.getInstanceMock(path);
    }

}
