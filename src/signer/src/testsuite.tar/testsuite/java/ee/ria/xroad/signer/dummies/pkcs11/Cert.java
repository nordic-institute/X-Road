package ee.ria.xroad.signer.dummies.pkcs11;

public class Cert {

}
